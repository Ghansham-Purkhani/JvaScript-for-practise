let numberTable = +prompt("enter number");
for(let i =1;i<=10;i++){
console.log("Table ====>",i + " x " + numberTable + "=" + numberTable*i );
}
